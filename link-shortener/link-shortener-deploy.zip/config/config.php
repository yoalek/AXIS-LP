<?php
// Database Configuration
define('DB_HOST', 'srv2020.hstgr.io');
define('DB_USER', 'u147689915_alek');
define('DB_PASS', '12203303Rpb.');
define('DB_NAME', 'u147689915_axislp');

// FTP Configuration (For Deployment)
define('FTP_HOST', '82.25.73.176');
define('FTP_USER', 'u147689915.alekteste');
define('FTP_PASS', '12203303Rpb.');
define('FTP_REMOTE_PATH', '/'); // Root folder on server as specified

// App Configuration
define('BASE_URL', 'https://coral-kudu-139947.hostingersite.com');
define('DEBUG_MODE', true);
